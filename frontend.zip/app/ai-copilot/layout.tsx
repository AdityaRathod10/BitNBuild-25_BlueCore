import type React from "react"
export default function AICopilotLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
